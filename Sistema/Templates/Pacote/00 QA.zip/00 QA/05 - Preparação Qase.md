---
tags:
  - qa
  - qase
tipo: referencia
status: rascunho
tipo_card: melhoria
projeto: ""
modulo: ""
qase_projeto: SGV
qase_suite_id: ""
demanda: "[[Sistema/Templates/Pacote/00 QA/Melhoria/01 - Demanda]]"
casos_origem: "[[Sistema/Templates/Pacote/00 QA/03 - Casos de teste]]"
validacao_origem: "[[Sistema/Templates/Pacote/00 QA/04 - Validação dev]]"
---
# Preparação Qase — <ID>

> [!info]- Navegação QA
> **README do card:** [[Sistema/Templates/Pacote/00 QA/00 README|Abrir README do card]]
> **Demanda/Bug:** [[Sistema/Templates/Pacote/00 QA/Melhoria/01 - Demanda]]
> **Plano de teste:** [[Sistema/Templates/Pacote/00 QA/02 - Plano de teste]]
> **Casos de teste:** [[Sistema/Templates/Pacote/00 QA/03 - Casos de teste]]
> **Validação:** [[Sistema/Templates/Pacote/00 QA/04 - Validação dev]]
> **Preparação Qase:** [[Sistema/Templates/Pacote/00 QA/05 - Preparação Qase]]
> **Automação:** [[../01 Automação/00 - Automação|Automação]] *(opcional — só quando houver cobertura automatizada)*

Esta nota transforma os CTs refinados do vault em casos da Qase. Não cria CT novo: apenas traduz os casos já existentes em `03 - Casos de teste` (só depois de aprovados na validação) para os campos da API.

> [!warning] Pendência
> `qase_suite_id` ainda não confirmado — nunca assumir/criar suite sem perguntar (ver [[../../../Skills/SKILL_SYNC_QASE|SKILL_SYNC_QASE]], GATE 2). Verificar suites existentes em `https://app.qase.io/project/SGV` antes do envio real.

## Configuração

- **Projeto Qase:** `SGV`
- **Suite Qase:** `<a confirmar>`
- **Origem:** [[Sistema/Templates/Pacote/00 QA/03 - Casos de teste]] (CT-001 a CT-NNN — todos aplicáveis, nenhum "Não se aplica")
- **Script/payload:** processo real descrito em [[../../../Skills/SKILL_SYNC_QASE|SKILL_SYNC_QASE]] — pasta `Sistema/Scripts/qase-sync/<contexto>/` no vault (`sync.js` + `corrections.json` + `README.md`), copiada da versão mais recente já usada. Não vive no repo de automação.

## Mapeamento dos campos

| Vault | Qase | Regra |
|---|---|---|
| Título do CT | `title` | mantém o título humano do cenário; CTs de regressão levam o prefixo `[REGRESSÃO]` |
| Descrição + critério de aceite | `description` | nunca deixar vazio |
| Pré-condições | `preconditions` | copiar sem misturar com os passos |
| Dado/Quando/Então | `steps` | separar cada ação do resultado esperado — um CT com múltiplos pares vira múltiplos steps |
| Pós-condição | `postconditions` | só quando agrega algo além do resultado esperado do último step |
| Tipo, severidade, automação | `type`/`severity`/`automation` | **inteiros reais na API**, não texto — usar só rótulos já confirmados contra a Qase real (`--inspect` num caso existente). Camada (UI/API/E2E) é só organização do vault, não é campo da Qase |

**Nunca inventar rótulo de enum.** Rótulos confirmados até 24/09/2026: `severity: normal` (4), `type: acceptance` (7), `automation: is-not-automated` (0). Não existe `type` de "regressão" confirmado neste projeto — CTs de regressão usam `acceptance` mesmo, sinalizados pelo prefixo `[REGRESSÃO]` no título.

`priority` e `behavior` ficam de fora do payload por padrão — preencher manualmente na Qase depois, se fizer sentido.

Tags da nota: manter somente `qa` e `qase`. Tags enviadas ao Qase: ID da demanda + módulo (ex. `SGV-XXXX`, `tramitação`) — não criar uma tag por CT.

## Casos preparados

> Nenhum caso foi enviado ainda. Os `Qase ID` ficam em branco até o `--apply`.

### CT-001 — <título do cenário>

- **Qase ID:** `preencher após o envio`
- **Descrição:** <resumo do objetivo + critério coberto>
- **Pré-condições:** <estado necessário antes do teste>
- **Passo 1 — Ação:** <ação>
  **Resultado esperado:** <resultado>
- **Pós-condição:** <estado após o teste, se agregar algo além do resultado>
- **severity:** normal · **type:** acceptance · **automation:** is-not-automated
- **Tags Qase:** `<ID da demanda>`, `<módulo>`

> **Regra:** critérios, evidências, esforço e resultado da execução continuam no vault ou no Test Run; não duplicar esses dados no caso da Qase.

## Checklist de envio

- [ ] Todos os CTs candidatos têm descrição, pré-condições e passos.
- [ ] Projeto e suite confirmados (suite pré-existente ou criada com autorização explícita).
- [ ] Campos normalizados e passos separados.
- [ ] Tags limitadas ao ID da demanda e ao módulo.
- [ ] Campos da API validados (`dry-run` rodado antes do `--apply`).
- [ ] Envio realizado sem duplicação.
- [ ] IDs da Qase registrados nesta nota.
- [ ] Status alterado para `enviado`.
